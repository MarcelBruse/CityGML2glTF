# CityGML2X

A command line interface for the CityGML2X library
