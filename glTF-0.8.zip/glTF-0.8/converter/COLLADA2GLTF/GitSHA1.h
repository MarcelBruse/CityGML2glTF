extern char g_GIT_SHA1[];
